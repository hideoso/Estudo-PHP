<?php

$empresa = "Impacta Certificação e Treinamento";

require "links.php";
echo "<strong>Empresa:</strong> ".$empresa;

?>