<?php

$cliente = 'Impacta Certificação e Treinamento';
$site = 'www.impacta.com.br';
$email = 'impacta@impacta.com.br';

echo '<strong>DADOS DO CLIENTE</strong>';
echo '<br/>';
echo '<strong>Cliente: </strong><i>'.$cliente. '</i><br/>';
echo '<strong>Site: </strong><i>' .$site. '</i><br/>';
echo '<strong>E-mail: </strong><i>' .$email. '</i><br/>';

?>