<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de Senha</title>
</head>
<body>
    <h1>Login</h1>
    <form action="index.php" method="post">
        <label for="id_email">E-mail:</label>
        <input id="id_email" type="email" name="email" required>
        <br>
        <label for="id_senha">Senha:</label>
        <input id="id_senha" type="password" name="senha" required>
        <br>
        <input type="submit" value="Entrar">
    </form>

    <a href="esqueci.php">Esqueci a Senha</a>
</body>
</html