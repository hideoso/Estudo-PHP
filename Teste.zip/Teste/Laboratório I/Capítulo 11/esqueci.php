<?php
// 5. Novo bloco de código PHP
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 7. Função para carregar classes automaticamente
    function autoLoadClasses($class) {
        include "classes/" . $class . ".php"; // Supondo que suas classes estejam na pasta "classes"
    }
    spl_autoload_register('autoLoadClasses');

    // 8. Função para sanitizar a entrada
    function post($chave) {
        return isset($_POST[$chave]) ? str_replace("'", "", $_POST[$chave]) : null; 
    }

    // 9. Recuperando o e-mail enviado via POST
    $email = post('email');

    // 10. Instanciando a classe Sql
    $sql = new Sql();

    // 11. Executando a consulta SQL
    $query = "SELECT senha FROM login WHERE email = :email"; // Usar prepared statements seria ideal
    $stmt = $sql->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    // 13. Verificando se retornou algum registro
    if ($stmt->rowCount() == 0) {
        echo "Endereço de e-mail incorreto!";
        exit;
    }

    // 14. Obtendo o valor do campo senha
    $usuario = $stmt->fetch(PDO::FETCH_OBJ);
    $senha = $usuario->senha; // A senha pode estar armazenada de forma segura (criptografada)

    // 15. Adicionando a classe PHPMailer
    require 'PHPMailer/PHPMailerAutoload.php'; // Ajuste o caminho conforme sua estrutura de pastas

    // 16. Instanciando a classe PHPMailer
    $mail = new PHPMailer;

    // 17. Configurando o e-mail de remetente
    $mail->isSMTP();
    $mail->Host = 'smtp.seuservidor.com'; // Endereço do servidor SMTP
    $mail->SMTPAuth = true; 
    $mail->Username = 'seuemail@seudominio.com'; // Usuário do e-mail
    $mail->Password = 'suasenha'; // Senha do e-mail
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587; // A porta pode variar

    // 18. Configurando o destinatário
    $mail->setFrom('seuemail@seudominio.com', 'Seu Nome'); // E-mail e nome do remetente
    $mail->addAddress($email); // E-mail do destinatário

    // 19. Mensagem de assunto
    $mail->Subject = 'Recuperação de Senha';

    // 20. Corpo do e-mail
    $mail->Body = 'Sua senha é: ' . $senha;

    // 21. Enviando o e-mail
    if ($mail->send()) {
        // 22. Mensagem de sucesso
        echo 'Sua senha foi enviada para e-mail: ' . $email;
    } else {
        echo 'Erro ao enviar e-mail: ' . $mail->ErrorInfo;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de Senha</title>
</head>
<body>
    <h1>Recuperação de Senha</h1>
    <form action="#" method="post">
        <label for="id_email">Digite o seu e-mail:</label>
        <input id="id_email" type="text" name="email" required />
        <input type="submit" value="Recuperar Senha" />
    </form>
</body>
</html>