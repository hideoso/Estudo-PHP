<?php

define("NOME", "valor");
define("HOME", "home.php");
define("CADASTRO", "cadastro.php");
define("CONSULTA", "lista.php");
define("ALTERACAO", "altera.php");
define("EXCLUSAO", "exclui.php");
define("SAIR", "sair.php")

?>