<?php

require "links.php";

echo 'Nome: '. NOME . '</br>';
echo 'Home: '. HOME . '</br>';
echo 'Cadastro: '. CADASTRO . '</br>';
echo 'Consulta: '. CONSULTA . '</br>';
echo 'Alteração: '. ALTERACAO . '</br>';
echo 'Exclusão: '. EXCLUSAO . '</br>';
echo 'Sair: '. SAIR . '</br>';

?>