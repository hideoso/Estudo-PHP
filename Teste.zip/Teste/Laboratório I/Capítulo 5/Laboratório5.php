<?php

$estadocivil = array(
    'Escolha uma opção',
    'Solteiro',
    'Namorando',
    'Noivo',
    'Casado',
    'Separado',
    'Divorciado',
    'Viúvo',
);
?>

<select name = "estadocivil">
<?php
foreach($estadocivil as $key => $value){
    echo "<option value= '$key'>$value</option>";
}   
?>
</select>