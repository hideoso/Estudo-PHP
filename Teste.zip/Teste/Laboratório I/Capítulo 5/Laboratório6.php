<?php

$produtos = array(
    'Tênis Adidas' => 525.00,
    'Óculos Ray-Ban' => 410.50,
    'Camiseta Polo' => 135.30,
    'Calça Jeans' => 120.50,
    'Blusa Vans' => 100
);

print_r($produtos);

// Adicionando 10% aos preços
foreach ($produtos as &$value) {
    $value += $value * 0.10;
}
echo '<br/>';

// Exibir preços com aumento
print_r($produtos);

?>