<?php

for($x=1; $x<=30; $x++){

    if($x%2==0) {
    echo $x. ': par<br/>';
    }
    else{
        echo $x. ': ímpar<br/>';
    }
}

?>