<?php

for($x=2; $x<=9; $x++){

    echo "$x - ";
    for($y=1; $y<=10; $y++)
{

        echo $x * $y;

        if ($y < 10) {
            echo " ";
        }
    }
    echo '<br/>';
}
?>