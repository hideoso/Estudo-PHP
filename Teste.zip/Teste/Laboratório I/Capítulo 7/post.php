<!doctype html>
<html>
    <head><title>Laboratório 7</title></head>
    <boyd>
    <div>
    <p>Veja o resultado com POST:
    </p>

    <form method="post" action="funcoes.php">
        <p>
        Pesquisar: <input type="text" name="chave" size="60">
        </p>
        <p>
        <input type="submit"value="enviar">
        </p>

    </form>

    </div>
    </boyd>
</html>