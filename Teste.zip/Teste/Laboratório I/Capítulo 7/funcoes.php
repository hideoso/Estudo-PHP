<?php

function post($chave) {
    $chave = $_POST["chave"];
}

?>