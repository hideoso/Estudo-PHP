<?php

define("titulo","Treinamento PHP I");
define("equipe","PHP Team");
$nome = "Juliana Almeida";

?>
<!doctype html>
<html>
    <head><title> <?php echo titulo ?> </title></head>
    <body>
    <div>
    <p>Olá <?php echo $nome ?>, obrigado por ter se cadastrado em nosso sistema, <br />
    clique no link abaixo para confirmar seu cadastro.
    </p>

    <p>
    <a href="#" alt=="exemplo de link">https://localhost/</a>
    </p>

    <p>Atenciosamente, <br /> <?php echo equipe ?> </p>
    </div>
    </body>
</html>