<!DOCTYPE html>
<html>
    <body>
    
    <form action="#" method="post" enctype="multipart/form-data">
        <label for="arquivo">Arquivo:</label>
        <input type="file" name="arquivo" id="arquivo" />
        <br />
        <input type="submit" value="Upload" />
    </form>

    </body>
</html>

<?php

if(move_uploaded_file($_FILES["arquivo"]["tmp_name"], $caminho)) {

    $mysql = new MySqli('localhost', 'root', '', 'php_modulo_ii');

    $mysql->query("
        INSERT INTO uploads (caminho, nome, data, tamanho)
        VALUES('".$caminho."', '".basename($caminho)."', '".date('Y-m-d H:i:s')."', ".filesize($caminho).")
    ");
}
?>