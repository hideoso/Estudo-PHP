<!DOCTYPE html>
<html>
    <body>

    <form action="#" method="post" enctype="multipart/form-data">
        <label for="arquivo">Arquivo:</label>
        <input type="file" name="arquivo" id="arquivo" />
        <br />
        <input type="submit" value="Upload" />
    </form>

    </body>
</html>
<?php

if($_SERVER['REQUEST_METHOD']=='POST') {
    $pasta = 'cap_6';

    if(!is_dir($pasta)) mkdir($pasta);

    $caminho = $pasta . "/" . $_FILES["arquivo"]["name"];

    if(move_uploaded_file($_FILES["arquivo"]["tmp_name"], $caminho)) {
        echo 'Upload realizado com sucesso!';

    }else{

        echo 'Problemas com upload!';
    }
    
}

?>