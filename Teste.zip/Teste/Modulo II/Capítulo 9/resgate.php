<?php

try {
    // Conectamos via Mysql
    $pdo = new PDO("mysql:dbname=meubanco", 'root', '');

    // Informamos que o PDO mostrará exceção quando der erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepara a operação e guarda em $stmt, nada é executado ainda
    $stmt = $pdo->prepare("SELECT * FROM clientes WHERE id=id");

    // Agora passamos os valores
    // filtrando por int
    $stmt->bindValue(':num', 5, PDO::PARAM_INT);

    // Para executar
    $stmt->execute();

    // Resgatamos o valor em Objeto
    $cli = $stmt->fetchAll(PDO::FETCH_OBJ);

    // Corremos a array pegando
    // todos os nomes
    foreach ($cliente as $cli) {    
        echo $cli->nome . '<br>';
    }
    
}   catch (PDOException $e) {
        echo $e->getMessage();
}