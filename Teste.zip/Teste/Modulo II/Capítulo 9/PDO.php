<?php

try {
    // Conectamos via Mysql
    $pdo = new PDO("mysql:dbname=meubanco", 'root', '');

    // Informamos que o PDO mostrará exceção quando der erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepara a operação e guarda em $stmt, nada é executado ainda
    $stmt = $pdo->prepare("INSERT INTO clientes
        (nome, email) VALUES (:nome, :email)");
    //  (nome, email) VALUES (?, ?)");
    //  (nome, email) VALUES (Lucas Arts, lu@gmail.com)");

    // Agora passamos os valores
    // Sendo sequencial
    // $stmt->bindValue(1, 'Lucas Filmes');
    // $stmt->bindValue(2, 'lufi@gmail.com');
    $stmt->bindValue(':nome', 'Steven Spielberg', PDO::PARAM_STR);
    $stmt->bindValue(':email', 'steve@gmail.com', PDO::PARAM_STR);

    // Para executar
    $stmt->execute(['George Lucas', 'geo@gmail.com']);

}   catch (PDOException $e) {
        echo $e->getMessage();
}