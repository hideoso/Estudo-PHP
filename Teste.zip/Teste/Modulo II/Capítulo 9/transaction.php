<?php

try {
    // Conectamos via Mysql
    $pdo = new PDO("mysql:dbname=meubanco", 'root', '');

    // Informamos que o PDO mostrará exceção quando der erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Entramos em modo temporário
    $pdo->beginTransaction();

    $pdo->exec("INSERT INTO clientes
        (nome, email) VALUES ('Pedro', 'pe@em.com')");
    
    $pdo->exec("INSERT INTO clientes
        (nome, email) VALUES ('João', 'joe@em.com')");

    // Erro nesta query fará cair no "catch"
    $pdo->exec("INSERT INTO clientes
        (nome, email) VAL ('Chaves', 'chavis@em.com')");
    
    $pdo->exec("INSERT INTO clientes
        (nome, email) VALUES ('Julia', 'ju@em.com')");
    
    // Caso chegue aqui deu tudo certo
    // commit grava definitivo os dados
    $pdo->commit();

}   catch (PDOException $e) {
        echo $e->getMessage();
        // Colocamos aqui o rollback
        // pois caso de erro cai aqui
        // volta tudo que foi feito
        $pdo->rollBack();
}