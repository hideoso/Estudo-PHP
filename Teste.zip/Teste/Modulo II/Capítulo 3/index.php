<?php

require 'Cliente.php';

$cliente = new MeuProjeto\Cliente;