<?php

namespace MeuProjeto;

class Cliente
{
    // Data de criação doi objeto
    public $data_cli;

    // Constroi a Datetime
    // contendo o valor data e hora atual
    public function __construct()
    {
        // Observe o \ antes da chamada da classe
        // Pois como DateTime é na nativa do PHP
        // não tem namespace
        $this->data_cli = new \DateTime();
    }
}