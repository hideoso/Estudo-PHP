<?php

namespace MeuProjeto;

class Cliente { }