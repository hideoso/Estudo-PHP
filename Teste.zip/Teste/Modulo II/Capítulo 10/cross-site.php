<?php

$comentario = "<p><strong>Formatação<br/>XHTML</strong></p><script>alert('Javascript!');</script>";

// Removendo todas as tags
echo strip_tags($comentario, '<br/>');

// Removendo todas as tags exceto a tag <br/>
echo strip_tags($comentario, '<br/>');

?>