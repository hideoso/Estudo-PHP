<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    $mysql = new MySqli('localhost', 'root', '', 'php_modulo_ii');

    $email = str_replace("'","",$_POST['email']);
    $senha = str_replace("'","",$_POST['senha']);

    $sql = "SELECT * FROM usuarios WHERE email = '$email' and senha = '$senha'";

    // Retire o comentário abaixo para visualizar a query que será execeutada:
    // echo $sql;

    $result = $mysql->query($sql);

    if($result->num_rows) {

        $registro = $result->fetch_object();
        echo '<p>Usuário autenticado como: <strong>'.$registro->nome.'</strong></p>';

    }else{

        echo '<p>Login ou Senha incorretos!</p>';

    }

    $mysql->close();

    exit();

}

?>
<form method="POST">
    <label for="email">E-mail:</label>
    <input type="text" id='email' name="email" />
    <br/>
    <label for="senha">Senha:</label>
    <input type="password" id="senha" name="senha" />
    <br/>
    <input type="submit" value="Ok" /> 
</form>