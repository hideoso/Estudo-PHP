<?php

$comentario = "<p><strong>Formatação<br/>XHTML</strong></p><script>alert('Javascript!');</script>";

// Sem htmlentities
echo $comentario;

// Com htmlentities
echo htmlentities($comentario);

?>