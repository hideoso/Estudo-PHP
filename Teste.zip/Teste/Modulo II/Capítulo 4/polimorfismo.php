<?php

abstract class Cliente
{
    protected $saldo_min;

    public function saldoMinimo()
    {
        $this->saldo_min = 0;
    }
}

class Fisico extends Cliente
{
    // Alterando a forma antiga de saldo
    // minimo da classe Cliente
    public function saldoMinimo()
    {
        $this->saldo_min = 100;
    }
}
class Juridico extends Cliente
{

}

// Imprime 100
$fisico = new Fisico;
$fisico->saldoMinimo();
echo $fisico->saldo_min;

// Imprime 0
$jur = new Juridico;
$jur->saldoMinimo();
echo $jur->saldo_min();