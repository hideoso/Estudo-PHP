<?php

class Cliente
{
    public $nome;
    public $email;
    public $conta;
}

class ContaCorrente
{
    public $id;
    public $tipo;
}

$conta = new ContaCorrente;
$conta->id = 11233;
$conta->tipo = 'simples';

$pf = new Cliente;
$pf->nome = 'Leonardo';
$pf->email = 'leo@gmail.com';

// Colocamos o objeto anteriormente
// criando a propriedade conta
$pf->conta = $conta; // <-- Associação aqui