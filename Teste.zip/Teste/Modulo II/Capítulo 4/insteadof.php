<?php

trait Registro
{
    public function save()
    {
        echo 'grava na Session';
    }
}

trait Database
{
    public function save()
    {
        echo 'grava no banco';
    }
}
// Gostaríamos de usar os 2 métodos
// Registro::save e Database::save
// Para isso precisamos definir um alias
class Cliente {
    use Registro, Database {
        // Indicamos quando chamar save
        // sera da classe Registro
        Registro::save insteadof Database;
        Database::save as saveDb;
    }
}

$cli = new Cliente;

// Chama Registro::save
$cli->save();

// Chama Database::save
$cli->saveDb();