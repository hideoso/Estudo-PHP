<?php

class Motor {

    public $hp = 100;

    public function __clone() {

        $this->hp += 10;

    }

}

$motor1 = new Motor();
$motor2 = clone $motor1;

var_dump($motor1);
var_dump($motor2);
?>