<?php

interface RelationalMapperInterface
{
    public function gravar();
    public function getTodos();
    public function getPorId($id);
    public function delete();
}

abstract class Registro implements RelationalMapperInterface
{
    public $id;
    public $nome;
    public $tabela;

    // Definir qual a tabela do banco
    abstract public function setTabela();

    public function gravar()
    {
        // Operação gravar genérica
    }
    public function getTodos()
    {
        // Operação getTodos genética
    }
    public function getPorId($id)
    {
        // ...
    }
    public function delete()
    {

        // ...
    }
}
// Herdando a Registro
class Cliente extends Registro
{
    public function setTabela()
    {
        $this->tabela = 'tbl_clientes';
    }
}

// Herdando a Registro
class Produto extends Registro
{
    public function setTabela()
    {
        $this->tabela = 'tbl_produtos';
    }
}

$cli = new Cliente(/*dados do Cliente novo */);
$prod = new Produto(/*dados do Produto*/);

// Grava os dados na tabela
// tbl_clientes
$cli->gravar(); // Método da DataMapperInterface

// Grava os dados na tabela
// tbl_produtos
$prod->gravar(); // Método da DataMapperInterface