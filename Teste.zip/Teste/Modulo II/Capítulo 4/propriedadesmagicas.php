<?php
class Pessoa {

    public function __set($propriedade, $valor) {
        echo "Foi atribuido o valor <b>$valor</b> na propriedade <b>$propriedade</b></br>";
    }

    public function __get($propriedade) {
        echo "Recuperando o valor da propriedade <b>$propriedade</b></br>";
    }

    public function __isset($propriedade) {
        echo "Verificando se a propriedade <b>$propriedade</b> foi atribuida</br>";
    }
    
    public function __unset($propriedade) {
        echo "Removendo a propriedade <b>$propriedade</b></br>";
    }

}

$pessoa = new Pessoa;
$pessoa->nome = 'João';
isset($pessoa->nome);
echo $pessoa->nome;
unset($pessoa->nome);
?>