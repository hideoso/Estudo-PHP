<?php

trait Cabeca {
    public function see()
    {
        echo 'Robo olha!<br>';
    }
}
trait Bracos {
    public function punch()
    {
        echo 'Robo soca!<br>';
    }
}
trait Pernas {
    public function walk()
    {
        echo 'Robo andando!<br>';
    }
}

class MaximusPrime
{
    use Cabeca, Bracos, Pernas;
}

$maximus = new MaximusPrime;
$maximus->see();
$maximus->punch();
$maximus->walk();