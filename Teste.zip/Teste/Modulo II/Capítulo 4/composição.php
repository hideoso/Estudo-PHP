<?php

class Cabeca { }
class Bracos { }
class Pernas
{
    public function walk()
    {
        echo 'Robo andando!';
    }
}

class Robo
{
    public $cabeca;
    public $bracos;
    public $pernas;

    public function __construct()
    {
        // Criando os objetos aqui!
        $this->cabeca = new Cabeca;
        $this->bracos = new Bracos;
        $this->pernas = new Pernas;
    }
}

$maximusPrime = new Robo;
// Objeto esta contido na propriedade
// pernas
$maximusPrime->pernas->walk();