<?php

class Aluno
{
    public $nome;

    public function __construct($nome)
    {
        $this->nome = $nome;
    }
}

class SalaDeAula
{
    protected $alunos = [];

    // Usamos type hinting para só permitir
    // objetos da classe Aluno
    public function addAluno(Aluno $aluno)
    {
        $this->alunos[] = $aluno;
    }
    // Imprime o total de alunos da sala
    public function total()
    {
        echo count($this->alunos);
    }
}

$sala = new SalaDeAula();
$sala->addAluno(new Aluno('Leonardo'));
$sala->addAluno(new Aluno('Luciana'));
$sala->addAluno(new Aluno('Adriana'));
$sala->addAluno(new Aluno('Pamela'));

$sala->total();