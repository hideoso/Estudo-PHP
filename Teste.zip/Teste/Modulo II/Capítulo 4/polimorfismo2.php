<?php

abstract class Cliente
{
    public $nome;

    public function imprimeDados ()
    {
        echo $this->nome . '<br>';
    }
}

class Fisico extends Cliente
{
    // Reescrevendo imprimedados
    public function imprimeDados()
    {
        echo 'Cliente pessoa física:<br>';
        // Reaproveitamos a ação da classe
        // pai Cliente
        parent::imprimeDados();
    }
}

class Juridico extends Cliente
{
    public $cnpj;
    // Reescrevendo imprimedados
    public function imprimeDados()
    {
        // Adicionando ação antes
        echo 'Cliente pessoa Jurídica:<br>';
        // Reaproveitamos a ação da classe
        // pai cliente
        parent::imprimeDados();
        // Adicionando ação depois
        echo 'Cnpj: ' . $this->cnpj; 
    }
}