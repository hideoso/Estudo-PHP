<?php

// Classe base para registrar
// no banco
abstract class Registro
{
    public $id;
    public $nome;
    public $tabela;

    // Definir qual a tabela do banco
    abstract public function setTabela();
}

// Herdando a Registro
class Cliente extends Registro
{
    public function setTabela()
    {
        $this->tabela = 'tbl_cliente';
    }
}

// Classe errada precisa implementar
// o método setTabela
class Produto extends Registro
{

}

$cli = new Cliente;
$robo = new Produto;