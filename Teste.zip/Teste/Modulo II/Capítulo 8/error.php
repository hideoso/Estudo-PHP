<?php

function teste($x) {
    if ($x==0) {
        throw new ErrorException('Não pode ser zero.');
    }
    else return $x;
}

try{

    echo teste(5).'</br>';
    echo teste(0).'</br>';

}catch(ErrorException $e) {

    echo $e->getMessage();

}

?>