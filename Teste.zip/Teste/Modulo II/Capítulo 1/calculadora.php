<?php

$valor1 = 232;
$valor2 = 82;

echo "$valor1 * $valor2 = " . $valor1 * $valor2;