<?php

echo 'Ola mundo via terminal';