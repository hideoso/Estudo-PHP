<?php

var_dump(simplexml_load_file("cap_4_ex_5.xml"));

$string = '
        <documento>
            <nome>Teste</nome>
            <login>joao</login>
            <data>' . time().'</data>
        <documento>
';

echo '<br/>';

var_dump(simplexml_load_string($string));

?>