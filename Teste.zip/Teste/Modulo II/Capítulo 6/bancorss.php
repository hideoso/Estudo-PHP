<?php

header("content-type: text/xml");
$xmlstr = <<<XML
<?xml version='1.0' standalone='yes'?>
<rss>

</rss>
XML;

$rss = new SimpleXMLElement($xmlstr);

$channel = $rss->addChild('channel');

$title = $channel->addChild('title', 'Exemplo de RSS');
$language = $channel->addChild('language', 'pt');
$link = $channel->addChild('link', 'http://www.impacta.com.br');

$mysql = new MySqli('localhost', 'root', '', 'php_modulo_ii');
$result = $mysql->query("SELECT * FROM rss");

while($line = mysqli_fetch_object($result)) {
    $item = $channel->addChild('item');
    $title = $item->addChild('title', utf8_encode($line->title));
    $description = $item->addChild('description', utf8_encode($line->description));
    $link = $item->addChild('link', utf8_encode($line->link));

}

echo $rss->asXML();

?>