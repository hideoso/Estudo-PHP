<?php

$string = <<<XML
<linguagem>PHP</linguagem>
XML;

$xml = new SimpleXMLElement($string);

var_dump($xml->saveXML('cap_4_ex_7.xml'));

?>