<?php

$xml = new SimpleXMLElement(file_get_contents('cap_4_ex_6.xml'));
var_dump($xml);

?>