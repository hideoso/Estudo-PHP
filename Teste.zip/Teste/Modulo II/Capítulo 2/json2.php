<?php

$array = [
        "continentes"=> [
                ["nome"=>"America"],
                ["nome"=>"Europa"],
                ["nome"=>"Asia"],
                ["nome"=>"Africa"],
                ["nome"=>"Oceania"],
                ["nome"=>"Antartida"]
        ]
];

echo var_dump(json_encode($array));