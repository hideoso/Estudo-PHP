<?php

$json = <<<JSON
{
    "clientes" : [
        { "nome" : 'Leornardo' },
        { "nome" : 'Ana' },
        { "nome" : "Carla" },
        { "nome" : "Marcos" },
        { "nome" : "Vivian" }
    ]
}
JSON;

$clis = json_decode($json);

switch (json_last_error()) {
    case JSON_ERROR_SYNTAX:
        echo 'Erro na sintaxe do JSON';
        break;
    case JSON_ERROR_NONE:
        echo 'Sem erros no json';
        break;
}