<?php

$json_string = '{
                    "continentes": [
                        {"nome":"America"},
                        {"nome":"Europa"},
                        {"nome":"Asia"},
                        {"nome":"Africa"},
                        {"nome":"Oceania"},
                        {"nome":"Antartida"}
                    ]
                }';

var_dump(json_decode($json_string, true));

?>