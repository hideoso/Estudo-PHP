<?php

class User
{
    public $nome;
    public $email;
    public $tel;
    public $end;

    // Construtor para popular os dados
    public function __construct()
    {
        $this->nome = 'Leonardo';
        $this->email = 'leo@gmail.com';
        $this->tel = '11 5555-5555';
        $this->end = 'Rua teste, 123';
    }
}

$user = new User;

echo json_encode($user);