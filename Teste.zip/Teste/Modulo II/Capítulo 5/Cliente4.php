<?php

// Classe cliente ficará extensa e é muito
// genérica se tivermos mais versões de clientes
// no futuro a manutenção será mais complexa!
class Cliente
{
    public function descontoGold() {}
    public function descontoSilver() {}
    public function descontoBronze() {}

    public function taxaGold() {}
    public function taxaSilver() {}
    public function taxaBronze() {}
}

class Planos
{
    public $total;

    public function __construct ($valor, $cliente)
    {
        $cli = new Cliente();
        // Repare no if se um cliente novo surgir
        // mais ifs serão colocados
        if ($cliente == 'Gold') {
            echo $cli->descontoGold($valor);
            echo $cli->taxaGold();
        } elseif ($cliente == 'Silver') {
            echo $cli->descontoSilver($valor);
            echo $cli->taxaSilver();
        } else {
            echo $cli->descontoBronze($valor);
            echo $cli->taxaBronze();
        }
    }
}