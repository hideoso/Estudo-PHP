<?php

// Criamos uma interface para obrigar
// nossas classes Strategy a usa-la
interface PlanosInterface
{
    public function desconto($valor);
    public function taxa();
}

class ClienteGold implements PlanosInterface
{
    public function desconto($valor)
    {
        // desconto 25%
        return $valor - ($valor * 0.25);
    }

    public function taxa()
    {
        return 100;
    }
}

class ClienteSilver implements PlanosInterface
{
    public function desconto($valor)
    {
        // Desconto 15%
        return $valor - ($valor * 0.15);
    }
    public function taxa()
    {
        return 50;
    }
}

class ClienteBronze implements PlanosInterface
{
    public function desconto($valor)
    {
        // desconto 5%
        return $valor - ($valor * 0.05);
    }
    public function taxa()
    {
        return 20;
    }
}