<?php

require 'Cliente12.php';

$con = new Mysqli('localhost', 'root', '', 'meubanco');

$mapper = new ClienteMapper($con);

$cli = $mapper->findById(2);

var_dump($cli);