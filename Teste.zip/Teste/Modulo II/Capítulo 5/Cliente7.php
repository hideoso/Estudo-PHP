<?php

require 'Cliente5.php';
require 'Cliente6.php';

echo 'Cliente Gold, Calsa 60 reais c/ desconto: ';
// Informamos com qual classe estamos trabalhando
$plano = new Plano (new ClienteGold);
echo $plano->getTotal(60);
echo '<br>Taxa mensal: ' . $plano->getTaxa();
echo '<br>';

echo '<br>Cliente Silver, Calsa 60 reais c/ desconto: ';
$plano = new Plano(new ClienteSilver);
echo $plano->getTotal(60);
echo '<br>Taxa mensal: ' . $plano->getTaxa();
echo '<br>';

echo '<br>Cliente Bronze, Calsa 60 reais c/ desconto: ';
$plano = new Plano(new ClienteBronze);
echo $plano->getTotal(60);
echo '<br>Taxa mensal: ' . $plano->getTaxa();
echo '<br>';