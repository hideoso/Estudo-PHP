<?php

class Cliente
{
    public $id;
    public $name;
    public $email;

}

class ClienMapper
{
    protected $con;

    function __construct(Mysqli $con)
    {
        $this->con = $con;
    }

    public function findById($id)
    {
        $res = $this->con->query("SELECT * FROM clientes WHERE id=$id");
        $data = $res->fetch_all(MYSQLI_ASSOC) [0];
        $obj = $this->toObject($data);
        return $obj;
    }

    function toObject (array $data)
    {
        $cli = new Cliente;
        $cli->id = $data['id'];
        $cli->name = $data['name'];
        $cli->email = $data['email'];
        return $cli;
    }
}