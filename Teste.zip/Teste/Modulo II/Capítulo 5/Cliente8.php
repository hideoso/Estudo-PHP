<?php

class AppRegistry
{
    // Usamos uma propriedade estatica
    // assim sempre que instanciarmos
    // a classe os objetos estarão disponíveis
    private static $instance;

    // Adiciona o objeto na array de registros
    public function register($name, $obj)
    {
        self::$instance[$name] = $obj;
    }

    // Retorna o objeto pedido em $name
    public function get($name)
    {
        return self::$instance[$name];
    }
}