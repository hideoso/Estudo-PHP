<?php

namespace MVC\Controllers;
use MVC\Core\Controllers;

class SiteController extends Controller
{
    public function indexAction()
    {
        echo 'teste';
    }

    public function olaAction($nome)
    {
        echo "Ola $nome";
    }
}