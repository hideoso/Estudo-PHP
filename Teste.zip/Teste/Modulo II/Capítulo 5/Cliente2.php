<?php

// Namespace dos Factorys
namespace MeuApp\Factors;

class UserFactory
{
    // Qual classe sera instanciada
    public $classe;

    public function __construct($classe)
    {
        // Adicionamos o namespace das classes Clientes
        $this->classe = 'MeuApp\\Cliente\\' . $classe;

        // Caso não exista a classe, para o script
        if (!class_exists($this->classe))
        {
            exit("Classe $this->classe não existe");
        }
    }

    // O método que faz o factory
    // ele usa a string em this->classe
    // e retorna a instancia do objeto
    // ex: new 'ClienteSilver' ();
    public function create()
    {
        return new $this->classe();
    }
    
}