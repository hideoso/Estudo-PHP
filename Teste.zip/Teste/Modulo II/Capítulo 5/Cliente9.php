<?php
require 'registry.php';

$app_reg = new AppRegistry();
$app_reg->register('mysql',
    new Mysqli('localhost', 'root', '', 'meubanco'));

$date = new DateTime('2014-10-01',
    new DateTimeZone('America/Sao_Paulo'));

$app_reg->register('data_inicio', $date);

// Usando uma classe nova
class View { }
$app_reg->Register('view', new View);

// Para acessarmos nossos objetos em Registry
$reg2 = new AppRegistry();

$data = $reg2->get('data_inincio');
echo $data->format('d/m/Y H:i:s');

$db = $reg2->get('mysql');
$db = $db->query('SELECT * from tbl_clientes');

while ($cli = $res->fetch_assoc())
{
    echo $cli['nome'] . '<br>';
}

$view = $reg2->get('view');
var_dump($view);