<?php

interface DataRegister
{
    public function save($value);
}

class DbRegister implements DataRegister
{
    public function save($value)
    {
        echo "Grava $value no banco de dados<br>";
    }
}

class MongoRegister implements DataRegister
{
    public function save($value)
    {
        echo "Grava $value em MongoDB<br>";
    }
}

class Cliente
{
    public $nome;
    public $email;
    public $senha;

    function setRegister(DataRegister $reg)
    {
        $this->reg = $reg;
    }
    
    public function gravar()
    {
        $this->reg->save($this->nome);
        $this->reg->save($this->email);
        $this->reg->save($this->senha);
    }
}