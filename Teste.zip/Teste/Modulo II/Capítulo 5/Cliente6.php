<?php

// Essa classe funcionará para qualquer cliente
// basta especificarmos a classe necessária
class Plano
{
    // Classe que fara a operação
    public $tipoCli;

    // o type hinting exige somente classes
    // que implementam essa PlanosInterface
    public function __construct (PlanosInterface $tipo)
    {
        $this->tipoCli = $tipo;
    }
    public function getTotal($preço)
    {
        return $this->tipoCli->desconto($preço);
    }

    public function getTaxa()
    {
        return $this->tipoCli->taxa();
    }
}