<?php
// Carrega as classes o ideal
// seria com autoload
require 'factory.php';
require 'users.php';

// Alias para UsersFactory
use MeuApp\Factors\UserFactory;

// Recebe uma url com o tipo de cliente
// Poderia ser $_GET['url'] por exemplo
$tipoCli = 'ClienteGold';

// Diz ao factory qual classe queremos
$factory = new UserFactory($tipoCli);

// Retorna o objeto criado
$cliente = $factory->create();

var_dump($cliente);

// Usamos o método do objeto da classe
$cliente->mostrarPerfil();