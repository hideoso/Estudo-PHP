<?php

require 'DI.php';

// Criamos a classe principal
$cli = new Cliente();

// Definimos sua dependencia DbRegister
// para gravar no banco
$cli->setRegister(new DbRegister);

// Definimos as propriedades
// no objeto
$cli->nome = 'Leonardo';
$cli->nome = 'teste@teste.com';
$cli->senha = '123123';

// Ao gravar será feita a gravação
// do objeto da classe DbRegister
$cli->gravar();

echo '<br>';

// Mudamos a dependência para
// MongoRegister
$cli->setRegister(new MongoRegister);

// Executamos o método gravar
// de MongoRegister
$cli->gravar();
