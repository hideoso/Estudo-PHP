<?php

// Criamos aqui um arquivo teste com as classes
// Cliente obs: O ideal é ter um autoload para isso...

// Namespace das classes Clientes
namespace MeuApp\Clientes;

// Abstract para as classes filhas
abstract class Cliente
{
    public function mostrarPerfil() { }
}

class ClienteBronze extends Cliente { }

class ClienteSilver extends Cliente { }

class ClienteGold extends Cliente { }