<?php

$letras = array('A','B','C');

echo $letras[1];

?>