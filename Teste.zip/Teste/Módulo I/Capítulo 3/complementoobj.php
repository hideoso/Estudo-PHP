<?php

class Pessoa{}

$Joao = new Pessoa();

echo gettype($Joao);

?>