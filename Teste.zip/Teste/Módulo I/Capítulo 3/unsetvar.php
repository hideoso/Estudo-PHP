<?php

$empresa = "Impacta Certificação e Treinamento";

echo "<strong>Empresa:</strong> ".$empresa. "<br/>";

unset ($empresa);

echo "<strong>Empresa:</strong> ".$empresa. "<br/>";

?>