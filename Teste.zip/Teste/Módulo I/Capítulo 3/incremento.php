<?php

/*
 * Para adicionar ou remover 1 no valor da variável
 * utiliamos os operadores incrementais
 * e decrementais. São muito utilizados em laços.
 */

 $x = 2;
 $y = 50;

 //incrementa 1 em x
 $x++;

 echo $x; // Imprime 3

 echo '</br>';

 // Usamos o pré incremento do qual da prioridade
 // para o (++) adicionando +1 em $y antes de imprimir
 echo ++$y; // Imprime 51

 echo '<br>';

 // Agora que $x é 3 ao colocar o pós-decremento
 // Somente depois do echo o valor de $x será 2

echo $x--; // Imprime 3 e na próxima linha $x vale 2

echo '</br>';

echo $x; // Imprime 2