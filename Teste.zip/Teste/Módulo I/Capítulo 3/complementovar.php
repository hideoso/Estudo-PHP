<?php

$nome = 'João';

$nomeCompleto = "$nome Henrique";

echo $nomeCompleto;

?>