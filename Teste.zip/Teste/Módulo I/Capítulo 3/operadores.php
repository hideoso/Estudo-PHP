<?php

/*
 * Quamos temos condições simples
 * usamos o operador ternário
 */

$a = 150;
$b = "150";

echo ($a == $b?"Valores iguais":"Valores diferentes")."<br/>" ;

echo ($a === $b?"Tipos iguais":"Tipos diferentes")."<br/>" ;

?>