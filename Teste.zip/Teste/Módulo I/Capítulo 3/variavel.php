<?php

$a = &$b;

$b = 10;

echo $a;

?>