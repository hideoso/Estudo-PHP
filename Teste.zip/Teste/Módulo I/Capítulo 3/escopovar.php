<?php

$salario = 2000;

/**/
function aumento() {
    $salario = 3000;
    echo "salario: ".$salario."<br/>";
}

aumento();

echo "Salário fora da função: ".$salario;
?>