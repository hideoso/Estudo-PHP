<?php

$valor1 = 11; //Numérico Inteiro.
$valor2 = 2.5; //Númerico Flutuante.

echo $valor1;
echo '<br/>';
echo $valor2;

?>