<?php

$a = 'Google ';
$b = 'Chrome';

$c = $a.$b;

echo $c;
echo '<br/>';

$a .= $b;

echo $a;

?>