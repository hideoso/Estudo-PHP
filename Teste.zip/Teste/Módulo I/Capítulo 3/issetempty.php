//int isset(mixed var);
//int empty(mixed var);
