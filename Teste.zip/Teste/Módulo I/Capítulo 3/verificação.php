<?php

/*
 * Quando temos condições simples
 * usamos o operador ternário
 */

$status = 1;
$tipo = 1;
$pago = 0;

echo "Cliente: ".($status==1?"Ativo":"Inativo");
echo "<br/>";
echo "Tipo: ".($tipo==true?"Vip":"Normal");
echo "<br/>";
echo "Pago: ".($pago?"Sim":"Não");

?>