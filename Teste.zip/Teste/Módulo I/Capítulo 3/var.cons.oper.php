<?php

/*
 * Operadores de atribuição podem ser usados em
 * cálculos acumulativos, por exemplo em subtotais.
 */

$produto = "Apple MacBook Pro Core i5 2.4 GHz";
$valor = 3250.00;
$quantidade = 2;
$subtotal = $valor * $quantidade;
$frete = 21.00;
$frete *= $quantidade; // $frete = $frete * $quantidade;
echo "<strong>Produto: </strong> ".$produto."<br />";
echo "<strong>Valor: </strong> ".number_format($valor,2,",","")."<br /><br />";
echo "<strong>Subtotal: </strong> ".number_format($subtotal,2,",","")."<br />";

$subtotal += $frete; //Subtotal = $subtotal + frete;
echo "<strong>Total: </strong> ".number_format($subtotal,2,",","")."<br />";

?>