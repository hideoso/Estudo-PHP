<?php

$navegador = getenv("HTTP_USER_AGENT");

//ou poderia ser
$navegador2 = $_SERVER["HTTP_USER_AGENT"];
/*exibindo o navegador do usuário*/

echo "Navegador: ".$navegador."<br />";
echo "Navegador2: ".$navegador2."<br />";

?>