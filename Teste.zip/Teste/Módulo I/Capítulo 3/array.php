<?php

$paises = array('Brasil', 'Argentina', 'Estados Unidos');

var_dump($paises);

?>