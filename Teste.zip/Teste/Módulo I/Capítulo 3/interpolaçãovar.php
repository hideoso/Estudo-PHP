<?php

$cliente = "José da Silva";

//ou poderia ser
$agradecimento = "Olá $cliente obrigado por comprar conosco! ";

echo $agradecimento;

?>