<?php

$ip = getenv("REMOTE_ADDR");

/*exigindo o ip em um alert Javascript*/
?>
<script>
    alert("Pegamos o seu IP \n <?php echo $ip;?>");
    document.location.href=("http://www.dpf.gov.br");
</script>