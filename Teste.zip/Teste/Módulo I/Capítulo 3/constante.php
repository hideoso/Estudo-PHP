<?php

/*
 * Criamos um arquivo para constantes
 * podemos colocar nesse aquivo
 * links, informações que raramente
 * ou nunca mudam.
 */

//título da página
define("TITULO","Treinamento PHP I");
//links
define("HOME", "home.php");
define("CADASTRO", "cadastro.php");
define("PRODUTOS", "produtos.php");
?>
<!doctype html>
<html lang="pt-BR">
    <head><title><?php echo TITULO?></title></head>
    </body>
    <a href="<?php echo HOME?>">Home</a> <br/>
    <a href="<?php echo CADASTRO?>">Cadastro</a> <br/>
    <a href="<?php echo PRODUTOS?>">Produtos</a> <br/>
    </body>
</html>