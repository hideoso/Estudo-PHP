<?php

$a = 51;

function testeEscopo() {
    global $a;

    echo $a; //A variável $a agora é global.

}

testeEscopo();

?>