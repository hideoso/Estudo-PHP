<?php
/*
 * Trabalhando com funções
 * Criamos 2 funções
 */

// Função para a conexão
// caso não dê certo retorna a conexão
function conecta ($banco, $dns='localhost', $user='root', $senha='') {
    // Caso der erro exibe a mensagem e para o programa
    $conn = mysqli_connect($dns, $user, $senha, $banco) or
        die('Desculpe-nos, passamos por um problema no momento.');
    if ($conn) {
        return $conn;
    }
}

// Função que desconecta o PHP do banco de dados
function desconecta($link) {
    mysqli_close($link);
}

// Realiza a conexão no banco php_modulo_1
$conn = conecta('php_modulo_1');

$sql = "INSERT clientes
(nome, telefone, endereco, email) VALUES
('Olivia Dunham', '11 2222-3333', 'Rua science finction, 12', 'oliv@mail.com')";

// Executando um INSERT na tabela clientes
$result = mysqli_query($conn, $sql);    

echo $result?'Usuário cadastrado com sucesso':'Erro ao incluir';

// Encerra a conexão com o banco
desconecta($conn);