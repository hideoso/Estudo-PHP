<?php
function conecta ($banco, $dns='localhost', $user='root', $senha='') {
    // Caso der erro exibe a mensagem e para o programa
    $conn = mysqli_connect($dns, $user, $senha, $banco) or
        die('Desculpe-nos, passamos por um problema no momento.');
    if ($conn) {
        return $conn;
    }
}
function desconecta($link) {
    mysqli_close($link);
}

$conn = conecta('php_modulo_1');

$result = mysqli_query($conn, 'SELECT * FROM clientes');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf8">
        <title>Listando uma tabela</title>
    </head>
    <body>
        <table style="width: 700px;">
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Telefone</th>
                <th>Endereço</th>
                <th>Email</th>
            </tr>
            <?php
                $cor = '';
                while ($cliente = mysqli_fetch_assoc($result)) {
                    $cor=$cor?'':'#0000FF';
                    echo '<tr style="background-color: ' . $cor .'">';
                    echo "<td>{$cliente['id']}</td>";
                    echo "<td>{$cliente['nome']}</td>";
                    echo "<td>{$cliente['telefone']}</td>";
                    echo "<td>{$cliente['endereco']}</td>";
                    echo "<td>{$cliente['email']}</td>";
                    echo '</tr>';
                }
                desconecta($conn);
                unset($conn);
            ?>
        </table>
    </body>
</html>