<?php

/*
 * Trabalhando com funções
 * Criamos 2 funções
 * 
 */

// Função para a conexão
// caso não dê certo retorna a conexão
function conecta ($banco, $dns='localhost', $user='root', $senha='') {
    // Caso der erro exibe a mensagem e para o programa
    $conn = mysqli_connect($dns, $user, $senha, $banco) or
        exit('Desculpe-nos, estamos passando por um problema no momento.');
    if ($conn) {
        return $conn;
    }
}

// Função que desconecta o PHP do banco de dados
function desconecta ($link) {
    mysqli_close($link);
}

// Realiza a conexão no banco test
$conn = conecta('test');
echo 'Conexão realizada com sucesso!';

//Encerra a conexão com o banco
desconecta($conn);
?>