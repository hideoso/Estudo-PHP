<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$email = new PHPMailer();

$email->IsSMTP();
$email->SMTPAuth = true;
$email->SMTPSecure = "ssl";
$email->Host = "smtp.gmail.com";
$email->Port = 465;
$email->Username = "phpmodulo1@gmail.com";
$email->Password = '$this->senha';

$email->IsSMTP(true);
$email->SetFrom('phpmodulo01@gmail.com', 'Curso PHP');
$email->Subject = "Testando PHPMailer com Gmail";
$email->MsgHTML('
    <h1>E-mail em HTML</h1>
    <p>Exemplo de List</p>
    <ul>
        <li>Item 1</li>
        <li>Item 2</li>
        <li>Item 3</li>
    </ul>
');

$email->AltBody = 'Mensagem alternativa.';
$email->AddAddress ("joaochrangel@gmail.com", "João Rangel");

if(!$email->Send()) {
    echo "Erro: " . $email->ErrorInfo;
}   else {
    echo "E-mail enviado";
}
?>