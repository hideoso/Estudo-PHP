<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$email = new PHPMailer();

try {

    $email->IsSMTP();
    $email->Host = "smtp.gmail.com";
    $email->SMTPAuth = true;
    $email->Username = "phpmodulo1@gmail.com";
    $email->Password = '$this->senha';
    $email->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $email->Port = 465;

    $email->setFrom('phpmodulo01@gmail.com', 'Curso PHP');
    $email->addAddress("joaohcrangel@gmail.com", "João Rangel");
    $email->Subject = "Testando PHPMailer com Gmail";
    $email->isHTML(true);
    $email->Body = '<h1>Este é um e-mail de teste!</h1>';
    $email->AltBody = 'Este é um e-mail de teste (versão texto).';

    $email->send();
    echo 'E-mail enviado com sucesso!';
}   catch (Exception $e) {
    echo "Erro ao enviar o e-mail: {$email->ErrorInfo}";   
}
?>