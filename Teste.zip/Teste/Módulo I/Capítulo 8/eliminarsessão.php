<?php
session_start();

//eliminando as variáveis de sessão
session_unset();

echo "Agora em outra página: ".$_SESSION["empresa"]."</br>";

?>