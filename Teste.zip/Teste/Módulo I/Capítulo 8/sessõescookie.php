<?php
session_start(); // Inicia as sessões nesta página, caso o PHP.ini não esteja configurado para iniciar automaticamente.

echo "Sua sessão é: ".session_id();

?>