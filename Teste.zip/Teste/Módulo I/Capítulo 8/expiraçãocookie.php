<?php

// Imaginamos que temos
// o cookie $_COOKIE['config'] já criado

// Alterando a data de expiração do cookie:

// devemos passar as informações do cookie atual novamente no segundo parâmetro
// Alteramos a data de expiração para 30 dias no terceiro
// Em uma outra ocasião, caso gostariamos de forçar a expiração
// basta criar o cookie com o nome config porém sem o terceiro parametro
// ex:

if(isset($_COOKIE['config'])) {
    setcookie('config', $_COOKIE['config'], time() + (30 * 24 * 60 *60)); // Expira em 30 dias
}

//Após essa linha o cookie 'config' estará indisponível para ser acessado
setcookie('cookie', '', 0);
?>  