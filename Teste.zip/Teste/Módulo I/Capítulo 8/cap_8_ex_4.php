<?php
session_start();

$_SESSION['curso'] = 'PHP Módulo I';

header('Location: cap_8_ex_5.php');

?>