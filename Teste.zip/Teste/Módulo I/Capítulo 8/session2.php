<?php
session_start();

echo "Agora em outra página: ".$_SESSION["empresa"]."</br>";

?>