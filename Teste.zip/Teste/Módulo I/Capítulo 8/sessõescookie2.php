<?php
session_start();

$_SESSION["empresa"] = "IMPACTA CERTIFICAÇÃO E TREINAMENTO";

echo "Empresa: ".$_SESSION["empresa"]."</br>";

?>
Veja em outra página: <a href="session2.php">clique aqui</a>