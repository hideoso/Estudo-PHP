<?php

if(!isset($_COOKIE["cordefundo"])) {
setcookie("cordefundo","#e1e1e1",time() +1); //válido por um dia
$cookie = "Configuração alterada com sucesso! </br> Pressione F5";
} else {
    $cookie = ""; //Evita erro de variável indefinida.
}

$fundo = isset($_COOKIE["cordefundo"]) ? $_COOKIE["cordefundo"] : "#e1e1e1";

?>
<!doctype html>
<html>
    <head><title>Treinamento PHP I</title></head>
    <body style="background-color:<?php echo $fundo?>">
    <div>
    <p>Usando cookies para armazenar informações de configuração</p>
    <p>Evite armazenar informações sigilosas em cookies. </p>
    </p>

    <?php if(!empty($cookie)) { ?>
        <p> <?php echo $cookie; ?> </p>
    <?php }   ?>
    </div>
    </body>
</html>
