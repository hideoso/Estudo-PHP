<?php

$decimal = 10.5;
$boleano = true;

settype($decimal, 'integer'); //O valor agora é: 10
settype($boleano, 'string'); //O valor agora é: '1'

echo $decimal;
echo '<br/>';
echo $boleano;

?>