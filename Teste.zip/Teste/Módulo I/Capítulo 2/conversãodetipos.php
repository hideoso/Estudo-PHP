<?php

$res = 5.2*3; //$res recebe 15.6

echo (int)$res; // Imprime 15

echo (int)5.5*3; // Converte primeiro 5.5 em 5 depois multiplica, resultado 15

$vbool = (bool)-12; //Qualquer numero diferente de 0 convertido em bool vira true

var_dump($vbool); // Imprime bolean true

var_dump((string)15); // Imprime string 15

var_dump((float)'2.5x'); // Imprime float 2.5