<?php

//Tipo de dados

/*bolean
Poderia ser 1, ou qualque valor diferente de zero,
diferente de vazio(empty, '', "") e diferente de null
*/
$status = true;
$bloqueado = false;

//o comando var_dump exibe a variável com sua estrutura
var_dump($status);
var_dump($bloqueado);

//integer
$idade = 30;
$código = 250;
var_dump($idade);
var_dump($código);

//float
$salário = 4560.50;
var_dump($salario);

//string
$nome = 'Fátima'; //texto estático
// com aspas duplas podemos  interpolar variáveis, sem precisar concatenar
$nomecompleto = "$nome Bernardes";

var_dump($nomecompleto);

?>