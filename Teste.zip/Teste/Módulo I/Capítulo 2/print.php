<?php
//Exemplo do comando print, e de uma variável.
print 'Escrevendo um texto com o comando print ';

//Toda variável no PHP é precedida por um cifrão($)
$empresa = 'Avançatech';

print $empresa;
//ou
echo "<br/>";
echo $empresa;
?>