<?php

$salario = 3000;
$aumento = .1;

echo 'Os salários terão aumento de 10%. De R$ '.$salario.' para R$ '.($salario+($salario*$aumento)).'.';

?>