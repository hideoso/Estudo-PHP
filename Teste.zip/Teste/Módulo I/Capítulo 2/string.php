<?php
//tipos de dados

/*
bolean
Poderia ser 1, ou qualquer valor diferente de zero, diferente de vazio(empty, '', "") e diferente de null
*/
$status = true;
$bloqueado = false;

//o comando var_dump existe a variável com sua estrutura
var_dump($status);
var_dump($bloqueado);

//integer
$idade  = 30;
$codigo = 250;
var_dump($idade);
var_dump($codigo);

//float
$salario = 4560.50;
var_dump($salario);

//string
$nome = 'Fátima '; //texto estático
//com aspas duplas podemos intepolar variáveis , sem precisar concatenar
$nomecompleto = "$nome Bernardes";

var_dump($nomecompleto);
?>