<?php
//Concatenação string

$nome = 'Lucas Hideo';
$email = 'lucas@gmail.com';
$site = 'www.avancatech.com.br';

echo '<strong>Nome: </strong>'.$nome.'<br />';
echo '<strong>E-mail: </strong>'.$email.'<br />';
echo '<strong>Site: </strong>'.$site.'<br />';

?>