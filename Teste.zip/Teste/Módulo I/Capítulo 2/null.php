<?php

$br = '<br/>';

$a = NULL;

$b = 10;
unset($b);

var_dump($a); //Retorna NULL, pois este valor foi atribuido.

echo $br;

var_dump($b); //Retorna NULL devido ao usio da função unset().

echo $br;

var_dump($c); //Retorna NULL porque a variavel $c não foi criada.

?>