<?php

echo 11;//Inteiro

echo '<br/>';

echo -11;//Inteiro Negativo;

echo '<br/>';

echo 011;//Notação Octal;

echo '<br/>';

echo 0x11;//Hexadecimal;

echo '<br/>';

?>