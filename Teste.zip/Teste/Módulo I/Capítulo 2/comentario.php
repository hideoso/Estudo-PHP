<?php
//Este é um comentário de linha, para breves descrições.

//O objetivo deste arquivo é mostrar o uso de comentários
#Podem ser escritos também com cerquilha
echo "<h1> Usando comentários</h1> <br/> <p> o comentário será ignorado</p>";

/*
Para documentar um código
ou ignorar diversas linhas usamos
o comentário de bloco.
Para documentação é recomnedável usare  o modelo abaixo
*/

/***
 * @autor: Lucas Hideo
 * @data: 2025-02-19
 * @objetivo: Modelo de comentário, o padrão usado nesse bloco poderá
 * ser lido por uma ferramenta de documentação, gerando os tópicos
 * automaticamente. Ex: http://www.phpdoc.org/
 */

?>