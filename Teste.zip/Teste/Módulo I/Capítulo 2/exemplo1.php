<?php

$cliente = 'José de Oliveira';

//usamos o Heredoc para textos de muitas linhas, como o corpo de um e-mail
$corpo = <<<HTML
<!doctype html>
<html>
    <head><title>Teste de corpo de E-mail</title></head>
    <body>
    <div>
    <p>Olá $cliente, obrigado por ter se cadastrado em nosso sistema, <br />
     clique no link abaixo para confirmar seu cadastro.
    </p>

    <p>
    <a href="#" alt="exemplo de link">http://localhost/</a>
    </p>

    <p>Atenciosamente, <br /> PHP Team </p>
    </div>
    </body>
</html>
HTML;

//perceba que para encerrar o comando usamos apenas o nome do identificador
echo $corpo;