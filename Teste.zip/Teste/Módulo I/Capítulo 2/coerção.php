<?php

$a = 5/2;
$b = 10/'2 alunos.';
$c = '3D'*2;
$d = 1.5*'-3x';

var_dump($a);
echo '<br/>';
var_dump($b);
echo '<br/>';
var_dump($c);
echo '<br/>';
var_dump($d);

?>