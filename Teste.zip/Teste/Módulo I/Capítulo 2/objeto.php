<?php

$objeto = new stdClass();

$objeto->nome = 'William';
$objeto->sobrenome = 'Bell';

var_dump($objeto);

?>