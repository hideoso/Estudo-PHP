<?php

class Pessoa{
    public $nome = '';//Propriedade
    public function alterarNome($novoNome) { //Método
        $this->nome = $novoNome;

    }
}

$alguem = new Pessoa();

?>