<?php
// Altera os charsets para UTF8 corrige erros de acertos
header ('Content-type: text/html; charset=UTF8');

class Valida {
    // Definimos que a qtd minima de
    // $parMin seja 3
    static public $parMin = 3;

    // Método que irá validar tamanho
    // máximo/mínimo de caracteres do valor
    static public function max($valor, $max, $charset='UTF-8')
    {
        // Pega o total de caracteres em UTF8
        $total_char = mb_strlen($valor, $charset);

        // Se o total de chars for menor que o padrão
        // Definido em $parMin 3
        if ($total_char < self::$parMin) {
            return false;
        }
        // Se o total de chars for maior que o
        // maximo passado pelo método
        if ($total_char > $max) {
            return false;
        }
        return true; // Caso não entre nos ifs acima
    }
}

$input1 = 'Teste é 123';
$input2 = 'INPUT INVÁLIDO MAIOR QUE 20 CHARS';
$input3 = 'a';

echo 'Valor mínimo padrão aceito: ' .Valida::$parMin.'<br/>';

// Acessando Valido:: max()
// não usamos o new e muito menos uma variável
if (Valida::max($input1, 20)) {
    echo 'Input validado com sucesso';
}
echo '<br>';
if (!Valida::max($input2, 20)) {
    echo 'Input inválido';
}
echo '<br>';
if (!Valida::max($input3, 20)) {
    echo 'Input inválido';
}