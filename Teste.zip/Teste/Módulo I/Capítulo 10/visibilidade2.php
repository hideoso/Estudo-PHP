<?php

class Exemplo {
    public function A () {


    }
    private function B () {


    }

    protected function C () {


    }
}

?>