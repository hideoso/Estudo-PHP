<?php

class Pessoa{
    public $nome = '';//Propriedade
    public function alterarNome($novoNome) { //Método
        $this->nome = $novoNome;

    }
}

class Usuario extends Pessoa{
    public $login;
    public function alterarLogin($novoLogin) {
        $this->login = $novoLogin;
    }
}

$usuario = new Usuario();
$usuario->alterarNome('João');

echo $usuario->nome;

?>