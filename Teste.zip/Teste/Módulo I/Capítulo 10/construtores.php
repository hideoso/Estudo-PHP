<?php

class HTML {

    public function __construct($titulo = 'Exemplos de Construtores') {

        echo '<!DOCTYPE html>
              <html lang="pt-br">
              <head>
                <meta charset=utf-8 />
                <title>'.$titulo.'</title>
              
              </head>
              <body>';

    }
}

?>