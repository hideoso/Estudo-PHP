<?php
// Altera os charset para UTF8 corrige erros de acentos
header ('Context-type: text/html; charset=UTF8');

// Colocamos a palavra chave final
// antes de class
final class Pessoa {
    public $nome = ''; // Propriedade
    public function alterarNome($novoNome) // Método
    {
        $this->nome = $novoNome;

    }
}

// Irá gerar um fatal error, pois pessoa é final e
// não pode ser extendida/herdada:
// Fatal error: Class Usuário may not inherit from final class (Pessoa)
class Usuario extends Pessoa {
    public $login;
    public function alterarLogin($novoLogin)
    {
        $this->login = $novoLogin;
    }
}