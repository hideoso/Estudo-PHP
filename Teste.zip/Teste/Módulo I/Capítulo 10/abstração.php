<?php
// Colocamos a palavra chave Abstract
// antes de class
abstract class Pessoa {
    public $nome = ''; // Propriedade

    public function alterarNome($novoNome) // Método
    {

        $this->nome = $novoNome;

    }
}

class Usuario extends Pessoa {

    public $login;

    public function alterarLogin($novoLogin)
    {
        $this->login = $novoLogin;
    }
}

// Irá gerar um fatal error:
// Fatal error: Cannot instantiate abstract class Pessoa
$pessoa  = new Pessoa;
$pessoa->alterarNome('Dexter');

echo $pessoa -> nome;