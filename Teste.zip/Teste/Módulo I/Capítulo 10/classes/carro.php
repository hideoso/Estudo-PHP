<?php

class Carro extends Veiculo {
    public $rodas = 4;

}

?>