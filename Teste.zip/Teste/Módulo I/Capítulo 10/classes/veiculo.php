<?php

class Veiculo {
    public $motor = 'sim';

}

?>