<?php

function _autoload($classe) {
    require_once("classes/$classe.php");

}

$gol = new Carro ();

echo $gol->motor.'<br/>';
echo $gol->rodas.'<br/>';

?>