<!doctype html>
<html>
    <head><title>Treinamento PHP I</title></head>
    <boyd>
    <div>
    <p>Veja o resultado com GET:
    </p>

    <p>
    <a href="get_02.php?id=10&lang=pt">clique aqui</a>
    </p>
    
    </div>
    </boyd>
</html>