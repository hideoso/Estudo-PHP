<!doctype html>
<html>
    <head><title>Treinamento PHP I</title></head>
    <boyd>
    <div>
    <p>Veja o resultado com GET:
    </p>

    <form method="get" action="get_04.php">
        <p>
        Pesquisar: <input type="text" name="q" size="60">
        </p>
        <p>
        <input type="submit"value="enviar">
        </p>

    </form>

    </div>
    </boyd>
</html>