<?php

$q = $_GET["q"];

echo "<strong>Palavra Pesquisada:</strong> ".$q;
?>