<?php

$codigo = $_GET["id"];

$idioma = $_GET["lang"];

echo "<strong>Código:</strong> ".$codigo."<br/>";
echo "<strong>Idioma:</strong> ".$idioma."<br/>";
?>