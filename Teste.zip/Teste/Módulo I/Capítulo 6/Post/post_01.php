<?php

$q = $_POST["q"];

echo "<strong>Palavra Pesquisada:</strong> ".$q;
?>