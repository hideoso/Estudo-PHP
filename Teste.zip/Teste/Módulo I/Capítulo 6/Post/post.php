<!doctype html>
<html>
    <head><title>Treinamento PHP I</title></head>
    <boyd>
    <div>
    <p>Veja o resultado com POST:
    </p>

    <form method="post" action="post_01.php">
        <p>
        Pesquisar: <input type="text" name="q" size="60">
        </p>
        <p>
        <input type="submit"value="enviar">
        </p>

    </form>

    </div>
    </boyd>
</html>