<?php

require "a.php";
echo "<strong>Empresa:</strong> ".$empresa;

?>