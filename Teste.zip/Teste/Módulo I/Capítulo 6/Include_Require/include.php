<?php

include "a.php";
echo "<strong>Empresa:</strong> ".$empresa;

?>