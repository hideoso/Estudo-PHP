<?php

echo "<strong>Empresa:</strong> ".$empresa;

?>