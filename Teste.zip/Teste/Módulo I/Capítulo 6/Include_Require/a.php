<?php

$empresa = "Impacta Certificação e Treinamento";

?>