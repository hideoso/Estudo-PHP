<?php

$paises = array(
                "c" => "Brasil",
                "b" => "Argentina",
                "a" => "Paraguai",
            );
        
krsort($paises);

foreach($paises as $chave => $valor) {

    echo $chave. ':'.$valor.'<br/>';

}
?>