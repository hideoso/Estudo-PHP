<?php

$frutas = array("Laranja", "Limão", "Abacaxi");

$outrasfrutas = array("Banana", "Maça", "Pêra");

print_r(array_merge($frutas, $outrasfrutas));

?>