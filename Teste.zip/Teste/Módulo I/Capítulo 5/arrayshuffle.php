<?php

$letras = array('A','B','C','D','E');

shuffle($letras);
print_r($letras);
echo '<br/>';

shuffle($letras);
print_r($letras);
echo '<br/>';

shuffle($letras);
print_r($letras);
echo '<br/>';

?>