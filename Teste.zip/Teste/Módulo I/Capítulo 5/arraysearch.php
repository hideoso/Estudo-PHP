<?php

$marcas = array (
                'Porsche',
                'Ferrari',
                'Lamborghini',
                'Aston Martin',
                'Maserati'
            );

print_r(array_search('Lamborghini', $marcas));

?>