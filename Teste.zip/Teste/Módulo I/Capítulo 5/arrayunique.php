<?php

$frutas = array('Maça', 'Abacaxi', 'Banana', 'Abacaxi');

print_r($frutas);

echo '<br/>';

print_r(array_unique($frutas));

?>