<?php

$marcas = array (
                'Porsche',
                'Ferrari',
                'Lamborghini',
                'Aston Martin',
                'Maserati'
            );

echo count($marcas);

?>