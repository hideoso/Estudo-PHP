<?php
// Forma antiga de uso
$produtos = array('Camiseta', 'Boné', 'Tênis', 'Meia');
var_dump($produtos);

//Forma de construção na versão 5.4+
$produtos_novo = ['Camiseta', 'Boné', 'Tênis', 'Meia'];
var_dump($produtos_novo);

// Abaixo uma representação dos produtos em novo
// formato de criação de arrays 5.4
$prod_completos = [
    [
        'id' => 1,
        'nome' => 'Camiseta',
        'valor' => 109.99,
        'qtd_estoque' => 20
    ],
    [
        'id' => 2,
        'nome' => 'Boné',
        'valor' => 79.99,
        'qtd_estoque' => 29
    ],
    [
        'id' => 3,
        'nome' => 'Tênis',
        'valor' => 350.52,
        'qtd_estoque' => 5
    ],
    [
        'id' => 4,
        'nome' => 'Meia',
        'valor' => 15.00,
        'qtd_estoque' => 50
    ]
];
var_dump($prod_completos);