<?php

$paises = array("Brasil", "Argentina", "Paraguai");
$capitais = array("Brasília", "Buenos Aires", "Assunção");

print_r(array_combine($paises, $capitais));

?>