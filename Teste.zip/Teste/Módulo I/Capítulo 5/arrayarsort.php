<?php

$paises = array(
                "c" => "Brasil",
                "b" => "Argentina",
                "a" => "Paraguai",
            );
        
arsort($paises);

foreach($paises as $chave => $valor) {

    echo $chave. ':'.$valor.'<br/>';

}
?>