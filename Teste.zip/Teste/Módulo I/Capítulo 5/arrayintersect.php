<?php

$letras1 = array('A','I','U','E','O');
$letras2 = array('I','M','P','A','C','T','A');

print_r(array_intersect($letras1, $letras2));

?>