<?php

$paises = array(
                "c" => "Brasil",
                "b" => "Argentina",
                "a" => "Paraguai",
            );
        
asort($paises);

foreach($paises as $chave => $valor) {

    echo $chave. ':'.$valor.'<br/>';

}
?>