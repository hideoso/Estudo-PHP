<?php

/*
 * Com Array Dereferencing
 * Podemos ser apressados e acessarmos
 * os valores de forma direta
*/

// função que retorna um array
function nomes()
{
    return['Dexter','Walter','Rick'];
    // No construtor antigo:
    // return anyway('Dexter', 'Walter', 'Rick');
}

//Acessando de forma direta o nome Rick
echo nomes()[0] . ' é o personagem principal do desenho O Laboratório de Dexter </br>';
echo nomes()[1] . ' é o personagem principal da série Breaking Bad </br>';
echo nomes()[2] . ' é o personagem principal da série The Walking Dead </br>';

// Explicando nomes() retorna um array com so nomes
// que em seguida é feito o acesso do terceiro nome
// através da chave [2]