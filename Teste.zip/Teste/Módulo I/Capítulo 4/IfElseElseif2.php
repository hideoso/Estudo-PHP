<?php

/*
 * Identificando o navegador do usuário
 * a função strpos detecta a posição
 * de uma String em um texto.
 */

$navegador = $_SERVER['HTTP_USER_AGENT'];

if(strpos($navegador, "iPad") == true){
    echo "Acessando do iPad";
}elseif(strpos($navegador, "Chrome") == true){
    echo "Acessando do Google Chrome";
}elseif(strpos($navegador, "Firefox") == true){
    echo "Acessando do Mozilla Firefox";
}elseif(strpos($navegador, "Safari") == true){
    echo "Acessando do Safari";
}elseif(strpos($navegador, "MSIE") == true){
    echo "Acessando do Microsoft Edge";
}

?>