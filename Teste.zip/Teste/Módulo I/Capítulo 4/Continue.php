<?php

for($j=0; $j<=5; $j++){

    if($j%2==0) continue;

    echo $j. '<br/>';
}
?>