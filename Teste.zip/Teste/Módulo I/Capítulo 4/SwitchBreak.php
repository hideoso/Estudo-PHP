<?php
/*
 * Utilizando o Switch para verificar
 * condfições pré-determinadas.
 */

 $nivel = 2;

 switch($nivel) {
    case 1 :
        echo "Fácil";
        break;
    case 2 :
        echo "Normal";
        break;
    case 3 :
        echo "Difícil";
        break;
    case 4 :
        echo "Impossível";
        break;
    default :
        echo "Opção inválida";
}
?>