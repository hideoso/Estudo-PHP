<?php
/*
 * Utilizando o comando for each para
 * percorrer um array
 */

// Pulamos uma linha para organizar o código fonte html
$carro = array(
    "Camaro",
    "Ferrari California",
    "Range Rover Sport",
    "Mercedes CLS 63 AMG"
);

// para cada item que exista em $carro;
// chame a posição de $chave e o valor de $modelo
foreach($carro as $chave => $modelo){
    echo "<strong>posição: $chave</strong> $modelo <br/>";
}

// Um exemplo prático
?>

<select name = "carro">
<?php
foreach($carro as $chave => $modelo){
    echo "<option value= '$chave'>$modelo</option>";
}
?>
</select>