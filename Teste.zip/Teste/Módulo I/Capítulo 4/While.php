<?php

/*
 * Utilizamos o comando While
 * para repetir uma sequência.
 */

$total = 10;
$x = 1;

while($x <= $total){
    echo $x. "<br/>";
    $x += 3;
}
// Para sair do laço deve estourar a condição.
echo "Agora fora do laço: ".$x;

?>