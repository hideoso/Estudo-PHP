<?php
/*
 * Utilizando o comando Do While
 * para repetir uma sequência.
 */

$total = 10;
$x = 11;

// Irá executar ao menos uma vez
do {
    echo $x. "<br/>";
    $x += 3;
}while($x <= $total);
// para sair do laço deve estourar a condição.
echo "Agora fora do laço: ".$x;
?>