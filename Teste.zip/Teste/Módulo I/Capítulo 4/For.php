<?php

for($x=0; $x<=date('s'); $x++){

    echo $x. '<br/>';

}

?>