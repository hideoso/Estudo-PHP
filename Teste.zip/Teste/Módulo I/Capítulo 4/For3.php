<?php
/*
 * Utilizando o comando for
 * para repetir uma sequência.
 * por uma quantidade fixa de vezes
 * o for é um contador, possui
 * valor inicial, valor final e incremento
 */
?>

Ano de fabricação: <select name = 'ano'>
<?php
for($ano = date("Y"); $ano >= 1920; $ano--){
    echo "<option value='$ano'>$ano</option>";
}
?>
</select>