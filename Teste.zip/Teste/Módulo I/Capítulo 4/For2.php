<?php
/*
 * Utilizando o comando for
 * para repetir uma sequência.
 * por uma quantidade fixa de vezes
 * o for é um contador, possui
 * valor inicial, valor final e incremento
 */

$tabuada = 2;

for($a = 1; $a <= 10 ; $a++) {
    echo $tabuada." x ".$a." = ".($tabuada * $a)." <br/>";

}
echo "<br/><br />";
for($a = 1 ; $a <= 10; $a++) {
    for($b = 1 ; $b <= 10 ; $b++) {
        echo $a." x ".$b." = ".($a * $b)." <br/>";
    }
echo "<br/><br/>";
}

?>