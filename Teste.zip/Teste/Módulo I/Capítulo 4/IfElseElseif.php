<?php

$hora = date('H');

if($hora>=7 && $hora <= 12) {
    echo 'Bom dia!';

}elseif($hora>=13 && $hora <= 18) {
    echo 'Boa tarde!';

}elseif($hora>=19 && $hora <= 23) {
    echo  'Boa noite!';

}else{
    echo 'Vai dormir!';

}

?>