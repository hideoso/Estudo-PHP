<?php

function  acrescimo_de_texto(&$string) {
    $string .= " acrescimo de texto";
}

$txt = 'Esse texto original terá';

acrescimo_de_texto($txt);

echo $txt;

?>