<?php

/*
 * Trabalhando com funções, quando a função não
 * possui o comando return é apenas uma sub-rotina
 */

$salario = 3500.00;

function cur($valor) {
    $novovalor = number_format($valor, 2, ",",".");
    $novovalor = "R$ ". $novovalor;

    return $novovalor;

}

echo cur($salario);

?>