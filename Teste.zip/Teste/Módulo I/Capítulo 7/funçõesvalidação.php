<?php

$valores = array(1,2,3,'A','B');

$i = rand(0,5);

if(is_numeric($valores[$i])) {

    echo "O índice $i possui um valor numérico.";

}else{

    echo "O índice $i NÃO possui um valor numérico.";
    
}

?>