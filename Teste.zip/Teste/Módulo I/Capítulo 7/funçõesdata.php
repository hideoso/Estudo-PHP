<?php

//date

echo date ('d/m/Y H:i:s').'<br/>';


//mktime

echo mktime (7,0,0, 3, 1, 2006);

//strtotime

echo strtotime ('now').'<br/>';
echo strtotime ('2001-09-11 8:46').'<br/>';

//time

echo date ('1', time());

?>