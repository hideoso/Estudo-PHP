<?php

//Função caractere

echo chr(65)

?>

<?php

// Função echo

echo 'Olá Mundo!';

?>

<?php

// Explode

$paises = 'Brasil - Argentina - Uruguai - Paraguai';

$array_paises = explode(' - ', $paises);

var_dump($array_paises);

?>

<?php

// Implode - une elementos de um array em uma string.

$tagsHTML = array ('html', 'head', 'body', 'form', 'label', 'input');

echo implode (' - ', $tagsHTML);

?>

<?php

// ord - retorna o valor ASCII do primeiro caractere de uma string.

echo ord ('A');

?>

<?php

// print - exibe uma string.

print('www.impact.com.br');

?>

<?php

//str_pad - ajusta uma string em posição de acordo com o espaço determinado, caso não haja espaço o preenchimento é automático.

for($x = 0; $x<=15; $x++) {
    echo str_pad($x, 2, 0, STR_PAD_LEFT).'<br/>';
}

?>

<?php

//str_replace

echo str_replace("$", "R$", "$ 10,00");

?>

<?php

//strlen

echo strlen('PHP');

?>

<?php

//strpos

echo 'A letra "H" está na posição: '.strpos('PHP', 'H');

?>

<?php

//strtolower

echo strtolower('Impacta Treinamentos e Certificação');

?>

<?php

//strtoupper

echo strtoupper('Impacta Treinamentos e Certificação');

?>

<?php

//substr

echo substr('Impacta Treinamentos e Certificação', -13). '<br/>';
echo substr('Impacta Treinamentos e Certificação', 7). '<br/>';
echo substr('Impacta Treinamentos e Certificação', 0, 7);

?>

<?php

//trim

echo trim(" Curso de PHP ");

?>

<?php

//ucfirst

echo ucfirst("joao henrique");

?>

<?php

//ucwords

echo ucwords("joao henrique");

?>