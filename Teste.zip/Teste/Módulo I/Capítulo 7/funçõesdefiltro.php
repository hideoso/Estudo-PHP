<?php

// mixed filter_var(mixed $variavel, $filtros, $options)

// Abrindo e-mail errado
$emailerrado = 'emailerrado.com.br';

// Imprime bool(false)
var_dump(filter_var($emailerrado, FILTER_VALIDATE_EMAIL));

// Atribuindo e-mail certo
$emailcerto = 'teste@gmail.com';

// Imprime string(15) "teste@gmail.com"
var_dump(filter_var($emailcerto, FILTER_VALIDATE_EMAIL));

// Valor de Id cheio de caracteres sem utilidadE
$campoId = "id'errdo2";

// Imprime 2 deixando somente o número 2
// Usando SANITIZE limpa o valor retornando 2
echo filter_var($campoId, FILTER_SANITIZE_NUMBER_INT);

// Cria uma simulação de SQL Injection
$sqlinjection = "Carlos ' or 1=1'";

// Imprime Carlos \' or 1=1\'
// escapa aspas simples com "\"
echo filter_var($sqlinjection, FILTER_SANITIZE_ADD_SLASHES);

// variável com tags HTML não desejáveis
$cross = "Carlos<script<alert('ataque cross scripting')</script>";

// Imprime Carlos <script>alert('ataque cross scripting')</script>
// e no font do HTML:
// Carlos&#60;script&#62;alert(&#39;ataque cross scripting&#39;)&#60;/script&#62;
echo filter_var($cross, FILTER_SANITIZE_SPECIAL_CHARS);