<?php

//number_format

echo number_format(2000,2,',','.');

//floatval - formata o valor uma variável como ponto flutuante

echo floatval('1234.56ABC');

//intval - formata o valor inteiro de uma variável

echo intval('1234.56ABC');

//max - retorna o maior valor informado no intervalo entre parenteses

$valores = array (10, 20, 30, 90, 80, 70, 60, 50, 40, 10);

echo max($valores);

//min - retorna o menor valor informado no intervalo entre parenteses

$valores = array (10, 20, 30, 90, 80, 70, 60, 50, 40, 10);

echo min($valores);

//rand - gera um valor inteiro aleatório

echo rand (10, 20);

//round - arredonda um ponto flutuante

$a = 1.4;
$b = 1.5;
$c = 1.6;

echo round($a).'<br/>';
echo round($b).'<br/>';
echo round($c).'<br/>';

?>