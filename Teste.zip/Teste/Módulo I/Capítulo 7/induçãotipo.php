<?php

// Indução de tipo

// Declaração de função
// Ao adicionarmos array na frente do parâmetro
// obrigamos que ele seja sempre um array
function imprimeDados (array $dados) {
    echo $dados['codigo'] . '<br/>';
    echo $dados['desc'];
}

// Exibirá um erro de PHP  informando que o
// parâmetro 1 é uma string e que deve ser um array
// imprimeDados ('Uma string qualquer');

$prod = array('codigo' => 13, 'desc' => 'Carrinho de mão');

// Irá exibir:
// 13
// Carrinho de mão
imprimeDados($prod);

// Obrigando um parâmetro função anônima
function func_exec(callable $anon_func) {
    $anon_func();
}

echo "<br/>";

// Podemos criar a closure direto no parâmetro
// ex:
func_exec(function(){ echo 'Ola mundo'; });