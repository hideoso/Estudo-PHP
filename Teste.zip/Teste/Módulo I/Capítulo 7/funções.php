<?php

/*
 * Trabalhando com funções, quando a função não
 * possui o comando return é apenas uma sub-rotina
 */

function exibe() {
    echo "<p>Escrevendo texto com uma sub-rotina </p>";
}

function exibe2() {
    $texto = "<p>Retornando um texto</p>";
    return $texto;
}
//Para que a função seja executada é necessário chamá-lo
exibe();

$resultado = exibe2();

echo "Agora armazenando o resultado em uma variável";

echo $resultado;

?>