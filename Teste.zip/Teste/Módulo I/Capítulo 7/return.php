<?php

function porcentagem($valor, $valorTotal){

    return ($valor*100)/$valorTotal.'%';

}

$a = 30;
$b = 200;

echo "$a é ".porcentagem($a, $b). " de $b.";

?>