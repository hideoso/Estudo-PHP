<?php

// Funções Anônimas / Closure / Lambda

// Declarando e atribuindo uma closure com parâmetro
// podemos usar quantos parâmetros precisarmos

$hello = function ($nome) {
    echo "Hello $nome";
}; // note o ; para finalizar sem ele teremos um erro

// Para executar a função
// basta chamar a variável e passar o parâmetro

$hello('Jason Born'); // observe $ necessário para executar

// Imprime Hello Jason Born

// ===== Recebendo variáveis externas =====

// Variável de scopo global

$nome = ' Walter White';

// instrução use() define quais variáveis externas
// poderão ser lidas como global
$hello2 = function () use ($nome) {
    // $nome é acessada externamente
    echo "$nome: Say my name!";
};

// Imprime Walter White: Say my name!
$hello2();