<?php

/*
 * Trabalhando com funções, usando valor padrão,
 * na chamada da função.
 */

function conecta($banco, $servidor="localhost",$usuario="root",$senha=""){
    //tornando a variável $conn publica.
    global $conn;
    $conn = mysqli_connect($servidor,$usuario,$senha,$banco)
    or exit();
    //como usamos o global conn, não é necessário retornar a variável.
    //return $conn;

}

function desconecta($conn) {
    mysqli_close($conn);
    unset($conn);
}

conecta("test");
echo "Conexão efetuada com sucesso!";
desconecta($conn);
?>