<?php

// Declaramos uma clase vazia
// somente para teste
class MinhaClasse {

}

// Após a classe existir
// na função obrigamos o parâmetro
// ser uma instância da classe MinhaClasse
function debug_class(MinhaClasse $miclass) {
    var_dump($miclass);
}

$obj = new MinhaClasse;

// Devemos obrigatoriamente passarmos
// uma objeto do tipo MinhaClasse
// Imprime object(MinhaClasse)#1 (0) { }
debug_class($obj);