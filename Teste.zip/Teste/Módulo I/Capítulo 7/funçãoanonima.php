<?php

// Funções Anônimas / Classe / Lambda

// Declarando e atribuindo uma closure
$func = function () {
    echo 'Função Closure!!';
}; // note o ; para finalizar sem ele produz um erro

// Para executar a função
// basta chamar a variável
$func(); // observe o $ necessário para executar

// Imprime Função Closure