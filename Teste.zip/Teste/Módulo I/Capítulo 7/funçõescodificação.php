<?php

//htmlentities - converte entidades HTML em caracteres aplicáveis
echo htmlentities('<strong>Texto</strong>');

//html_entity_decode
echo html_entity_decode('&lt;strong&gt;Texto&lt;/strong&gt;');

//utf8_encode
echo utf8_encode('João');

//utf8_decode
echo utf8_decode('João');

?>