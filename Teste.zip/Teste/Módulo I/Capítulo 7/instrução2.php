<?php

// Funções Anônimas / Closure / Lambda

// Criando uma função convencional
// a palavra chave callable garante que seja
// obrigado passar uma closure no segundo parâmetro
function chamadaInterna ($nome, callable $func) {
    // Esperamos receber uma Closure em
    // $func
    $func($nome);
}

/*
 * A função chamadaInterno invoca o segundo
 * parametro que deve ser uma closure
 * ela chama a closure e passa seu parametro
 * para a Closure
 * Imprime Olá Scarlett Johansson
 */
chamadaInterna ('Scarlett Johansson', function($nome) {
    echo 'Olá ' . $nome;
});

// Outra forma de chamar a Closure colocando-a 
// em uma variável e passando como parâmetro
$closure  = function($nome) {
    echo $nome;
};

// Imprime Olá Scarlett Johansson
chamadaInterna (' Scarlett Johansson', $closure);