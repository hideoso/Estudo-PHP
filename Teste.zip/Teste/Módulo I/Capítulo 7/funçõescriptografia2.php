<?php

$senha = 'teste123';

// Recebe hash que representa 'teste123'
// Relembrando que o hash muda a cada nova chamada

$hash = password_hash($senha, PASSWORD_BCRYPT);
echo 'Hash: ' . '</br>';
echo $hash;
echo '</br>';

echo 'Senha: ' . '<br>';
echo $senha;
echo '<br>';

// A função password_verify verifica
// A string com o hash e retorna true
// se for verdadeira ou false se não forem
// compatíveis
if (password_verify($senha, $hash)) {
    echo 'As senhas são iguais';
}

/*
Imprime:

Hash:
$2y$10$2I/wM3KaiEYn.laqxxdsSuAnn7Z7fasMI/NJebugid1vfLgdi5I6v.
Senha:
As senhas são iguais

*/